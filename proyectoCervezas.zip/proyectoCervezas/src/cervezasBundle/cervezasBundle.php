<?php

namespace cervezasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class cervezasBundle extends Bundle
{
}
