<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0daaa3d5cfd073d06a3840dd526eb53dc2929fac357308915d14d50f05ae0819 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bf1cdbc1875aaa00094a96ceabba06012a0694ff82ef49bf3e975961d14287df = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bf1cdbc1875aaa00094a96ceabba06012a0694ff82ef49bf3e975961d14287df->enter($__internal_bf1cdbc1875aaa00094a96ceabba06012a0694ff82ef49bf3e975961d14287df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_7045d6a5fb37cb0a3f796838094aeae38d6cc932d37b7bcceadf80d360562aa7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7045d6a5fb37cb0a3f796838094aeae38d6cc932d37b7bcceadf80d360562aa7->enter($__internal_7045d6a5fb37cb0a3f796838094aeae38d6cc932d37b7bcceadf80d360562aa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bf1cdbc1875aaa00094a96ceabba06012a0694ff82ef49bf3e975961d14287df->leave($__internal_bf1cdbc1875aaa00094a96ceabba06012a0694ff82ef49bf3e975961d14287df_prof);

        
        $__internal_7045d6a5fb37cb0a3f796838094aeae38d6cc932d37b7bcceadf80d360562aa7->leave($__internal_7045d6a5fb37cb0a3f796838094aeae38d6cc932d37b7bcceadf80d360562aa7_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_211385ce09cf9fa1d1a7a3bea13a1ba49e1d42f3df5e957e49c4ebc0d40869d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_211385ce09cf9fa1d1a7a3bea13a1ba49e1d42f3df5e957e49c4ebc0d40869d1->enter($__internal_211385ce09cf9fa1d1a7a3bea13a1ba49e1d42f3df5e957e49c4ebc0d40869d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_e2b50c3c5c267adb1db560b1546dd5858a611d63a7f1af4b849ed72761cb10e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2b50c3c5c267adb1db560b1546dd5858a611d63a7f1af4b849ed72761cb10e4->enter($__internal_e2b50c3c5c267adb1db560b1546dd5858a611d63a7f1af4b849ed72761cb10e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_e2b50c3c5c267adb1db560b1546dd5858a611d63a7f1af4b849ed72761cb10e4->leave($__internal_e2b50c3c5c267adb1db560b1546dd5858a611d63a7f1af4b849ed72761cb10e4_prof);

        
        $__internal_211385ce09cf9fa1d1a7a3bea13a1ba49e1d42f3df5e957e49c4ebc0d40869d1->leave($__internal_211385ce09cf9fa1d1a7a3bea13a1ba49e1d42f3df5e957e49c4ebc0d40869d1_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_30ba1f31ba3e372f681076edac0dcbeaccb3fbb8c14cbca2622cc131dffca8c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30ba1f31ba3e372f681076edac0dcbeaccb3fbb8c14cbca2622cc131dffca8c3->enter($__internal_30ba1f31ba3e372f681076edac0dcbeaccb3fbb8c14cbca2622cc131dffca8c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_36e27e5232bb43ab2ac03e652eb96285f89b316d614430b3adc1c0b157736560 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_36e27e5232bb43ab2ac03e652eb96285f89b316d614430b3adc1c0b157736560->enter($__internal_36e27e5232bb43ab2ac03e652eb96285f89b316d614430b3adc1c0b157736560_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_36e27e5232bb43ab2ac03e652eb96285f89b316d614430b3adc1c0b157736560->leave($__internal_36e27e5232bb43ab2ac03e652eb96285f89b316d614430b3adc1c0b157736560_prof);

        
        $__internal_30ba1f31ba3e372f681076edac0dcbeaccb3fbb8c14cbca2622cc131dffca8c3->leave($__internal_30ba1f31ba3e372f681076edac0dcbeaccb3fbb8c14cbca2622cc131dffca8c3_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_1f94981bb72556314c57f3e0585b252ac2b9c4d49fe76429c914e96154c60c55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1f94981bb72556314c57f3e0585b252ac2b9c4d49fe76429c914e96154c60c55->enter($__internal_1f94981bb72556314c57f3e0585b252ac2b9c4d49fe76429c914e96154c60c55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_46ecd2e41df8b48013d5c0b010a5dc75d35280348c31d6f5863886b0694d4bfe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46ecd2e41df8b48013d5c0b010a5dc75d35280348c31d6f5863886b0694d4bfe->enter($__internal_46ecd2e41df8b48013d5c0b010a5dc75d35280348c31d6f5863886b0694d4bfe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_46ecd2e41df8b48013d5c0b010a5dc75d35280348c31d6f5863886b0694d4bfe->leave($__internal_46ecd2e41df8b48013d5c0b010a5dc75d35280348c31d6f5863886b0694d4bfe_prof);

        
        $__internal_1f94981bb72556314c57f3e0585b252ac2b9c4d49fe76429c914e96154c60c55->leave($__internal_1f94981bb72556314c57f3e0585b252ac2b9c4d49fe76429c914e96154c60c55_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/javi/Documents/symfony/proyectoCervezas/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
