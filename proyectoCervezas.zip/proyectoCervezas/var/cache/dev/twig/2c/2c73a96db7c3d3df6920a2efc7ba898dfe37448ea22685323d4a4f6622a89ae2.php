<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_9686a4200268e8228f08a645977c6ab94f42aa617b6e80356a4d3defaa116264 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f735c48a35a076545451a09e5ea2ccb158b423528f6f16bf3518eae7f608aa6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f735c48a35a076545451a09e5ea2ccb158b423528f6f16bf3518eae7f608aa6->enter($__internal_8f735c48a35a076545451a09e5ea2ccb158b423528f6f16bf3518eae7f608aa6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_aeffda359c5bc644153725686ddb553a1382f876096be14e9e0e8924752a0ff6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aeffda359c5bc644153725686ddb553a1382f876096be14e9e0e8924752a0ff6->enter($__internal_aeffda359c5bc644153725686ddb553a1382f876096be14e9e0e8924752a0ff6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8f735c48a35a076545451a09e5ea2ccb158b423528f6f16bf3518eae7f608aa6->leave($__internal_8f735c48a35a076545451a09e5ea2ccb158b423528f6f16bf3518eae7f608aa6_prof);

        
        $__internal_aeffda359c5bc644153725686ddb553a1382f876096be14e9e0e8924752a0ff6->leave($__internal_aeffda359c5bc644153725686ddb553a1382f876096be14e9e0e8924752a0ff6_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_2ac7aa47fb7e9c3cbe239171fdec72ecbbc57a44930461a64530817abc9b1682 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ac7aa47fb7e9c3cbe239171fdec72ecbbc57a44930461a64530817abc9b1682->enter($__internal_2ac7aa47fb7e9c3cbe239171fdec72ecbbc57a44930461a64530817abc9b1682_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_2e68b132d905f92d32f2d0c8f5e833fe9ccd6dc649f968f7bbe18de1387b83bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e68b132d905f92d32f2d0c8f5e833fe9ccd6dc649f968f7bbe18de1387b83bb->enter($__internal_2e68b132d905f92d32f2d0c8f5e833fe9ccd6dc649f968f7bbe18de1387b83bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_2e68b132d905f92d32f2d0c8f5e833fe9ccd6dc649f968f7bbe18de1387b83bb->leave($__internal_2e68b132d905f92d32f2d0c8f5e833fe9ccd6dc649f968f7bbe18de1387b83bb_prof);

        
        $__internal_2ac7aa47fb7e9c3cbe239171fdec72ecbbc57a44930461a64530817abc9b1682->leave($__internal_2ac7aa47fb7e9c3cbe239171fdec72ecbbc57a44930461a64530817abc9b1682_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_d23258ca1b4dc209827efa8aba8a5ab337b06360afeae02c46fa012288d22361 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d23258ca1b4dc209827efa8aba8a5ab337b06360afeae02c46fa012288d22361->enter($__internal_d23258ca1b4dc209827efa8aba8a5ab337b06360afeae02c46fa012288d22361_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_2143281e5b98126a45a54c316297a672cffe3e8b482b625964997b75e9451f0d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2143281e5b98126a45a54c316297a672cffe3e8b482b625964997b75e9451f0d->enter($__internal_2143281e5b98126a45a54c316297a672cffe3e8b482b625964997b75e9451f0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_2143281e5b98126a45a54c316297a672cffe3e8b482b625964997b75e9451f0d->leave($__internal_2143281e5b98126a45a54c316297a672cffe3e8b482b625964997b75e9451f0d_prof);

        
        $__internal_d23258ca1b4dc209827efa8aba8a5ab337b06360afeae02c46fa012288d22361->leave($__internal_d23258ca1b4dc209827efa8aba8a5ab337b06360afeae02c46fa012288d22361_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_78c1f2f7d3a28118758c07060b0acace779084448735aa4180ac8ab3b2b5ee16 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78c1f2f7d3a28118758c07060b0acace779084448735aa4180ac8ab3b2b5ee16->enter($__internal_78c1f2f7d3a28118758c07060b0acace779084448735aa4180ac8ab3b2b5ee16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f6c035b9e0dfddb5f238ee2c19e825a2338064b511df5475daf81e0c4d68d054 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6c035b9e0dfddb5f238ee2c19e825a2338064b511df5475daf81e0c4d68d054->enter($__internal_f6c035b9e0dfddb5f238ee2c19e825a2338064b511df5475daf81e0c4d68d054_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_f6c035b9e0dfddb5f238ee2c19e825a2338064b511df5475daf81e0c4d68d054->leave($__internal_f6c035b9e0dfddb5f238ee2c19e825a2338064b511df5475daf81e0c4d68d054_prof);

        
        $__internal_78c1f2f7d3a28118758c07060b0acace779084448735aa4180ac8ab3b2b5ee16->leave($__internal_78c1f2f7d3a28118758c07060b0acace779084448735aa4180ac8ab3b2b5ee16_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/javi/Documents/symfony/proyectoCervezas/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
