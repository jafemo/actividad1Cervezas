<?php

/* cervezasBundle:Default:index.html.twig */
class __TwigTemplate_64c360f5cd24958b174136b4e79bb475fa90389437ee8690684f2fd7137a528a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e2c7a1821311b28b138b485dab6306c15f07a7b5cc926a326b2b7dfbaf868d4c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e2c7a1821311b28b138b485dab6306c15f07a7b5cc926a326b2b7dfbaf868d4c->enter($__internal_e2c7a1821311b28b138b485dab6306c15f07a7b5cc926a326b2b7dfbaf868d4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cervezasBundle:Default:index.html.twig"));

        $__internal_c79492c7c2a399e1c8761538df4bcbe2cdcb6b8a8f1842422559106e20e65062 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c79492c7c2a399e1c8761538df4bcbe2cdcb6b8a8f1842422559106e20e65062->enter($__internal_c79492c7c2a399e1c8761538df4bcbe2cdcb6b8a8f1842422559106e20e65062_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cervezasBundle:Default:index.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">
<body>
<h1>Cervezas</h1>
<div class=\"w3-container\">
  <div class=\"w3-panel w3-card w3-yellow\"><p>Cerveza 1</p></div>
  <div class=\"w3-panel w3-card-2 w3-yellow\"><p>Cerveza 2</p></div>
  <div class=\"w3-panel w3-card-4 w3-yellow\"><p>Cerveza 2</p></div>
</div>

</body>
</html>
";
        
        $__internal_e2c7a1821311b28b138b485dab6306c15f07a7b5cc926a326b2b7dfbaf868d4c->leave($__internal_e2c7a1821311b28b138b485dab6306c15f07a7b5cc926a326b2b7dfbaf868d4c_prof);

        
        $__internal_c79492c7c2a399e1c8761538df4bcbe2cdcb6b8a8f1842422559106e20e65062->leave($__internal_c79492c7c2a399e1c8761538df4bcbe2cdcb6b8a8f1842422559106e20e65062_prof);

    }

    public function getTemplateName()
    {
        return "cervezasBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
<link rel=\"stylesheet\" href=\"https://www.w3schools.com/w3css/4/w3.css\">
<body>
<h1>Cervezas</h1>
<div class=\"w3-container\">
  <div class=\"w3-panel w3-card w3-yellow\"><p>Cerveza 1</p></div>
  <div class=\"w3-panel w3-card-2 w3-yellow\"><p>Cerveza 2</p></div>
  <div class=\"w3-panel w3-card-4 w3-yellow\"><p>Cerveza 2</p></div>
</div>

</body>
</html>
", "cervezasBundle:Default:index.html.twig", "/Users/javi/Documents/symfony/proyectoCervezas/src/cervezasBundle/Resources/views/Default/index.html.twig");
    }
}
